# FeastFlow — EventEats Exchange

A beginner-friendly hackathon mini project for planning event catering. It includes a responsive React interface, a live quote calculator, menu selection, sample vendor comparison, tasting-request form, and a print-to-PDF quotation.

## Features

- Select an event type, guest count (50–500), and food preference.
- Add or remove dishes across starters, mains, live counters, and desserts.
- See a live per-plate and total estimate.
- Volume discount: 0% below 100 guests, 5% for 100–199, and 10% for 200+.
- Add a 10% portion buffer recommendation.
- Compare up to three sample caterers.
- Open a tasting-session request form.
- Export an itemized quotation using the browser's **Print → Save as PDF** option.
- Express API endpoints and sample seed data are included.

## Run the project

You need Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local Vite URL shown in the terminal (usually http://localhost:5173).

To run the optional Express API in a second terminal:

```bash
npm run server
```

The API runs at http://localhost:4000.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check server |
| GET | `/api/vendors` | List sample caterers |
| GET | `/api/menu` | List sample menu items |
| POST | `/api/quote` | Calculate a quote |
| POST | `/api/tasting-requests` | Validate a demo tasting request |

Example quote request:

```json
{
  "guests": 150,
  "itemIds": ["paneer", "corn", "dal", "veg-biryani", "gulab"]
}
```

## Pricing logic

`dish total × volume multiplier + service charge + live counter setup fee per guest`

- Under 100 guests: 1.00 multiplier
- 100–199 guests: 0.95 multiplier
- 200+ guests: 0.90 multiplier
- Staff/service estimate: ₹25 per guest
- Live-counter setup fees are divided across the guest count.

All vendors, ratings, prices and reviews are illustrative demo data, not real endorsements or live offers. The app does not process payments or send real tasting requests. Confirm food-safety documents, licences, portions, taxes and final pricing directly with a caterer before making a booking.

## Suggested demo flow

1. Choose **College fest** and set guests to **150**.
2. Keep the default vegetarian menu or customize the dishes.
3. Point out how the per-plate and total estimates update.
4. Compare Royal Feast Caterers and Spice Symphony.
5. Open a tasting request and submit sample details.
6. Export the quotation and save it as a PDF.

## Project structure

```text
feastflow-mini-project/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx
│   └── styles.css
├── server/
│   ├── index.js
│   └── seed.js
└── README.md
```

## Next improvements

- Store quotes and tasting requests in SQLite.
- Connect the React form to the Express endpoints.
- Add login, vendor verification documents, and real review moderation.
- Add separate vegetarian and non-vegetarian guest counts.
- Generate a server-side PDF and add GST/tax settings.
