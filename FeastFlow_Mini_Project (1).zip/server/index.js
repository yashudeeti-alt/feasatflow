import express from "express";
import cors from "cors";
import { vendors, menuItems } from "./seed.js";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "FeastFlow" }));
app.get("/api/vendors", (_req, res) => res.json(vendors));
app.get("/api/menu", (_req, res) => res.json(menuItems));

app.post("/api/quote", (req, res) => {
  const { guests = 100, itemIds = [] } = req.body || {};
  const count = Math.max(1, Number(guests) || 1);
  const items = menuItems.filter(item => itemIds.includes(item.id));
  const itemRate = items.reduce((sum, item) => sum + item.price, 0);
  const discount = count >= 200 ? 0.10 : count >= 100 ? 0.05 : 0;
  const servicePerGuest = 25;
  const setupFees = items.reduce((sum, item) => sum + (item.setupFee || 0), 0);
  const perPlate = Math.round(itemRate * (1 - discount) + servicePerGuest + setupFees / count);
  res.json({
    guests: count, selectedItems: items, itemRate, discount,
    servicePerGuest, setupFees, perPlate, total: perPlate * count,
    bufferPortions: Math.ceil(count * 1.10)
  });
});

app.post("/api/tasting-requests", (req, res) => {
  const { name, vendorId, date, venue } = req.body || {};
  if (!name || !vendorId || !date || !venue) {
    return res.status(400).json({ error: "Please provide name, vendor, date and venue." });
  }
  res.status(201).json({
    message: "Tasting request received (demo).",
    request: { name, vendorId, date, venue, status: "pending-demo" }
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`FeastFlow API running at http://localhost:${PORT}`));