export const vendors = [
  { id: 1, name: "Royal Feast Caterers", rating: 4.8, reviews: 126, startingPrice: 450, minGuests: 50, city: "Hyderabad" },
  { id: 2, name: "Spice Symphony", rating: 4.5, reviews: 89, startingPrice: 420, minGuests: 40, city: "Hyderabad" },
  { id: 3, name: "The Copper Ladle", rating: 4.7, reviews: 74, startingPrice: 510, minGuests: 75, city: "Secunderabad" }
];

export const menuItems = [
  { id: "paneer", name: "Paneer Tikka", course: "Starters", price: 65, diets: ["Veg", "Jain"] },
  { id: "corn", name: "Crispy Corn", course: "Starters", price: 45, diets: ["Veg", "Jain"] },
  { id: "gobi", name: "Gobi 65", course: "Starters", price: 50, diets: ["Veg"] },
  { id: "chicken", name: "Chicken 65", course: "Starters", price: 80, diets: ["Non-Veg"] },
  { id: "paneer-butter", name: "Paneer Butter Masala", course: "Mains", price: 85, diets: ["Veg"] },
  { id: "dal", name: "Dal Tadka", course: "Mains", price: 45, diets: ["Veg", "Jain"] },
  { id: "veg-biryani", name: "Veg Dum Biryani", course: "Mains", price: 75, diets: ["Veg"] },
  { id: "chicken-biryani", name: "Chicken Dum Biryani", course: "Mains", price: 105, diets: ["Non-Veg"] },
  { id: "roti", name: "Butter Naan", course: "Breads", price: 25, diets: ["Veg"] },
  { id: "chaat", name: "Chaat Counter", course: "Live counter", price: 55, setupFee: 1200, diets: ["Veg", "Jain"] },
  { id: "pasta", name: "Pasta Station", course: "Live counter", price: 70, setupFee: 1500, diets: ["Veg"] },
  { id: "dosa", name: "Dosa Station", course: "Live counter", price: 60, setupFee: 1000, diets: ["Veg", "Jain"] },
  { id: "gulab", name: "Gulab Jamun", course: "Desserts", price: 30, diets: ["Veg"] },
  { id: "icecream", name: "Ice Cream", course: "Desserts", price: 35, diets: ["Veg"] },
  { id: "payasam", name: "Payasam", course: "Desserts", price: 40, diets: ["Veg", "Jain"] }
];