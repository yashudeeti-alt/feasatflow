import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { CalendarDays, Check, ChefHat, ChevronDown, Clock3, Download, Heart, Leaf, MapPin, Plus, ShieldCheck, SlidersHorizontal, Sparkles, Star, Users, Utensils, X } from "lucide-react";
import "./styles.css";

const vendors = [
  { id: 1, name: "Royal Feast Caterers", tag: "Best rated", rating: 4.8, reviews: 126, base: 450, min: 50, city: "Hyderabad", color: "coral", about: "Thoughtful menus, traditional service and a team that keeps events running smoothly." },
  { id: 2, name: "Spice Symphony", tag: "Best value", rating: 4.5, reviews: 89, base: 420, min: 40, city: "Hyderabad", color: "green", about: "A crowd-pleasing mix of regional favourites and popular continental dishes." },
  { id: 3, name: "The Copper Ladle", tag: "Modern menus", rating: 4.7, reviews: 74, base: 510, min: 75, city: "Secunderabad", color: "blue", about: "Fresh presentation, live counters and flexible packages for special occasions." }
];

const menu = [
  { group: "Starters", icon: "🥗", items: [
    { id: "paneer", name: "Paneer Tikka", detail: "Smoky, tandoor-style cubes", price: 65, diets: ["Veg", "Jain"] },
    { id: "corn", name: "Crispy Corn", detail: "Golden corn with a light spice", price: 45, diets: ["Veg", "Jain"] },
    { id: "gobi", name: "Gobi 65", detail: "Crisp cauliflower bites", price: 50, diets: ["Veg"] },
    { id: "chicken", name: "Chicken 65", detail: "South Indian favourite", price: 80, diets: ["Non-Veg"] }
  ]},
  { group: "Main course", icon: "🍛", items: [
    { id: "paneer-butter", name: "Paneer Butter Masala", detail: "Creamy tomato gravy", price: 85, diets: ["Veg"] },
    { id: "dal", name: "Dal Tadka", detail: "Comforting yellow lentils", price: 45, diets: ["Veg", "Jain"] },
    { id: "veg-biryani", name: "Veg Dum Biryani", detail: "Fragrant basmati rice", price: 75, diets: ["Veg"] },
    { id: "chicken-biryani", name: "Chicken Dum Biryani", detail: "Layered with aromatic spices", price: 105, diets: ["Non-Veg"] },
    { id: "roti", name: "Butter Naan", detail: "Soft tandoor-baked bread", price: 25, diets: ["Veg"] }
  ]},
  { group: "Live counters", icon: "👨‍🍳", items: [
    { id: "chaat", name: "Chaat Counter", detail: "Pani puri and papdi chaat", price: 55, diets: ["Veg", "Jain"], fee: 1200 },
    { id: "pasta", name: "Pasta Station", detail: "Made fresh with your choice of sauce", price: 70, diets: ["Veg"], fee: 1500 },
    { id: "dosa", name: "Dosa Station", detail: "Crispy dosas made to order", price: 60, diets: ["Veg", "Jain"], fee: 1000 }
  ]},
  { group: "Desserts", icon: "🍨", items: [
    { id: "gulab", name: "Gulab Jamun", detail: "Warm, soft and syrupy", price: 30, diets: ["Veg"] },
    { id: "icecream", name: "Ice Cream", detail: "Two classic flavours", price: 35, diets: ["Veg"] },
    { id: "payasam", name: "Payasam", detail: "Traditional festive dessert", price: 40, diets: ["Veg", "Jain"] }
  ]}
];

function App() {
  const [guests, setGuests] = useState(100);
  const [event, setEvent] = useState("College fest");
  const [diet, setDiet] = useState("Veg");
  const [selected, setSelected] = useState(["paneer", "corn", "paneer-butter", "dal", "veg-biryani", "roti", "gulab", "icecream"]);
  const [compare, setCompare] = useState([1, 2]);
  const [booking, setBooking] = useState(false);
  const [bookVendor, setBookVendor] = useState(vendors[0]);
  const [toast, setToast] = useState("");
  const [date, setDate] = useState("");
  const [venue, setVenue] = useState("");
  const [name, setName] = useState("");

  const chosen = menu.flatMap(g => g.items).filter(i => selected.includes(i.id));
  const itemRate = chosen.reduce((sum, i) => sum + i.price, 0);
  const discount = guests >= 200 ? 0.10 : guests >= 100 ? 0.05 : 0;
  const serviceFee = 25;
  const liveFees = chosen.reduce((sum, i) => sum + (i.fee || 0), 0);
  const perPlate = Math.round(itemRate * (1 - discount) + serviceFee + liveFees / guests);
  const total = perPlate * guests;
  const buffer = Math.ceil(guests * 1.10);

  const toggleItem = (id) => setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const toggleCompare = id => setCompare(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const notify = msg => { setToast(msg); window.setTimeout(() => setToast(""), 2600); };
  const exportQuote = () => {
    const rows = chosen.map(i => `<tr><td>${i.name}</td><td>₹${i.price}</td></tr>`).join("");
    const html = `<!doctype html><html><head><title>FeastFlow Quote</title><style>body{font:15px Arial;padding:36px;color:#242424}h1{color:#d95d43}table{width:100%;border-collapse:collapse;margin-top:20px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left}.total{font-size:22px;font-weight:bold;margin-top:24px}</style></head><body><h1>FeastFlow</h1><h2>Event catering estimate</h2><p>${event} · ${diet} · ${guests} guests</p><table><tr><th>Menu item</th><th>Rate / guest</th></tr>${rows}</table><p>Service charge per guest: ₹${serviceFee}</p><p>Volume discount: ${Math.round(discount*100)}%</p><p class="total">Estimated total: ₹${total.toLocaleString("en-IN")} (₹${perPlate}/plate)</p><p>Recommended food buffer: ${buffer} portions</p><small>Estimate only. Final pricing and availability must be confirmed with the caterer.</small><script>window.print()</script></body></html>`;
    const w = window.open("", "_blank");
    if (!w) { notify("Please allow pop-ups to print your quote."); return; }
    w.document.write(html); w.document.close();
  };

  const openBooking = vendor => { setBookVendor(vendor); setBooking(true); };
  const submitBooking = e => { e.preventDefault(); setBooking(false); notify("Tasting request saved! The caterer can follow up with you."); };

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-mark"><Utensils size={19}/></span><span>feastflow<span className="brand-dot">.</span><small>EVENTEATS EXCHANGE</small></span></a>
      <nav><a href="#builder">Build a menu</a><a href="#vendors">Caterers</a><a href="#how">How it works</a></nav>
      <button className="outline-btn top-cta" onClick={() => document.getElementById("builder").scrollIntoView({behavior:"smooth"})}>Start planning <span>↗</span></button>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> GOOD FOOD. CLEAR NUMBERS.</div>
          <h1>Make room for<br/><em>great moments.</em></h1>
          <p>Plan your event menu, understand the cost per plate, and find a caterer you can count on. No endless phone calls needed.</p>
          <div className="hero-actions"><button className="primary-btn" onClick={() => document.getElementById("builder").scrollIntoView({behavior:"smooth"})}>Build your quote <span>→</span></button><span className="trust-note"><ShieldCheck size={16}/> Clear pricing, easier decisions</span></div>
          <div className="hero-stats"><div><strong>5 min</strong><span>to build an estimate</span></div><div><strong>3</strong><span>sample local caterers</span></div><div><strong>100%</strong><span>menu flexibility</span></div></div>
        </div>
        <div className="hero-art">
          <div className="art-note note-top"><span>✦</span> Made for your kind of gathering</div>
          <div className="food-photo"><div className="plate"><div className="food-center"><span>🍛</span><span>🥗</span><span>🫓</span><span>🍮</span></div></div></div>
          <div className="floating-card"><div className="float-icon"><Check size={16}/></div><div><b>Budget, sorted.</b><small>Know your per-plate estimate</small></div></div>
          <div className="art-caption">A little planning goes a long way.</div>
        </div>
      </section>

      <section className="section builder-section" id="builder">
        <div className="section-heading"><div><div className="eyebrow">01 / YOUR EVENT</div><h2>Let's set the table.</h2><p>Start with the basics. Your estimate updates as you make choices.</p></div><div className="step-pill"><span>1</span> Event details <i>—</i> <span>2</span> Menu <i>—</i> <span>3</span> Compare</div></div>
        <div className="builder-grid">
          <div className="builder-main">
            <div className="panel event-panel">
              <div className="panel-title"><div className="round-icon"><CalendarDays size={18}/></div><div><h3>What are we celebrating?</h3><p>Every occasion deserves a good meal.</p></div></div>
              <div className="field-label">EVENT TYPE</div>
              <div className="event-options">{["College fest","Birthday","Corporate","Wedding"].map((x,i)=><button key={x} onClick={()=>setEvent(x)} className={event===x?"event-option active":"event-option"}><span>{["🎓","🎂","💼","💐"][i]}</span>{x}</button>)}</div>
              <div className="guest-row"><div><div className="field-label">NUMBER OF GUESTS</div><div className="guest-number"><Users size={18}/><strong>{guests}</strong><span>people</span></div></div><div className="guest-input"><input type="range" min="50" max="500" step="10" value={guests} onChange={e=>setGuests(Number(e.target.value))}/><div className="range-labels"><span>50 guests</span><span>500 guests</span></div></div></div>
              <div className="diet-row"><div><div className="field-label">FOOD PREFERENCE</div><p>Choose the main menu style</p></div><div className="diet-options">{["Veg","Non-Veg","Jain"].map(x=><button key={x} className={diet===x?"diet-chip active":"diet-chip"} onClick={()=>setDiet(x)}>{x==="Veg"&&<Leaf size={13}/>} {x}</button>)}</div></div>
            </div>

            <div className="menu-heading"><div><div className="eyebrow">02 / BUILD YOUR MENU</div><h2>What's on the menu?</h2><p>Pick the dishes your guests will love. Prices shown are per person.</p></div><span className="selected-count">{selected.length} selected</span></div>
            <div className="menu-groups">{menu.map(group=><div className="panel menu-panel" key={group.group}>
              <div className="menu-group-title"><span className="group-emoji">{group.icon}</span><h3>{group.group}</h3><span className="group-count">{group.items.filter(i=>selected.includes(i.id)).length} selected</span><ChevronDown size={17}/></div>
              <div className="dish-grid">{group.items.filter(item=>item.diets.includes(diet) || diet==="Non-Veg" && item.diets.includes("Veg")).map(item=><button key={item.id} className={selected.includes(item.id)?"dish-card chosen":"dish-card"} onClick={()=>toggleItem(item.id)}><span className="dish-check">{selected.includes(item.id)?<Check size={13}/>:<Plus size={13}/>}</span><span className="dish-info"><b>{item.name}</b><small>{item.detail}</small>{item.fee&&<em>+ ₹{item.fee.toLocaleString("en-IN")} setup fee</em>}</span><strong>₹{item.price}</strong></button>)}</div>
            </div>)}</div>
          </div>

          <aside className="quote-card">
            <div className="quote-top"><div className="eyebrow">YOUR LIVE ESTIMATE</div><span className="live-dot">LIVE</span></div>
            <h3>A plan taking shape.</h3><p className="quote-sub">Your current event estimate</p>
            <div className="price-block"><span>Estimated per plate</span><div><small>₹</small>{perPlate.toLocaleString("en-IN")}</div><span className="price-total">₹{total.toLocaleString("en-IN")} total for {guests} guests</span></div>
            <div className="cost-lines"><div><span>Selected dishes ({chosen.length})</span><b>₹{itemRate}</b></div><div><span>Service & staff</span><b>₹{serviceFee}</b></div><div><span>Live counter setup</span><b>₹{liveFees.toLocaleString("en-IN")}</b></div><div className="discount-line"><span>Volume discount</span><b>{Math.round(discount*100)}% off</b></div></div>
            <div className="buffer-note"><Sparkles size={16}/><span><b>Smart portion cushion</b><small>Consider planning for {buffer} portions (+10%) to keep everyone happy.</small></span></div>
            <button className="primary-btn full-btn" onClick={exportQuote}><Download size={16}/> Export quotation</button>
            <p className="estimate-disclaimer">A planning estimate, not a final vendor offer. Taxes and venue-specific charges may vary.</p>
          </aside>
        </div>
      </section>

      <section className="vendor-section" id="vendors"><div className="section vendor-inner">
        <div className="section-heading"><div><div className="eyebrow">03 / FIND YOUR CATERER</div><h2>Good people. Good food.</h2><p>Compare sample caterers using the same menu and guest count.</p></div><span className="verified-label"><ShieldCheck size={16}/> Sample verified directory</span></div>
        <div className="compare-tools"><div><SlidersHorizontal size={16}/> <b>Compare caterers</b><span>Select up to 3 vendors</span></div><span>{compare.length} selected</span></div>
        <div className="vendor-grid">{vendors.map(v=><article className={`vendor-card ${compare.includes(v.id)?"vendor-selected":""}`} key={v.id}>
          <div className={`vendor-banner ${v.color}`}><span className="vendor-monogram">{v.name.split(" ").map(w=>w[0]).slice(0,2).join("")}</span><span className="vendor-tag">{v.tag}</span><button className={compare.includes(v.id)?"compare-check checked":"compare-check"} onClick={()=>toggleCompare(v.id)} aria-label="Toggle comparison">{compare.includes(v.id)&&<Check size={14}/>}</button></div>
          <div className="vendor-content"><div className="vendor-name-row"><h3>{v.name}</h3><span className="rating"><Star size={14} fill="currentColor"/> {v.rating}</span></div><p>{v.about}</p><div className="vendor-meta"><span><MapPin size={13}/>{v.city}</span><span><Users size={13}/> Min. {v.min} guests</span><span><ShieldCheck size={13}/> Profile checked*</span></div><div className="vendor-price"><div><small>Indicative starting price</small><strong>₹{Math.round(v.base*(1-discount)).toLocaleString("en-IN")}<small> / plate</small></strong></div><button className="text-btn" onClick={()=>openBooking(v)}>Request tasting <span>→</span></button></div></div>
        </article>)}</div>
        <div className="comparison-wrap"><div className="comparison-title"><div><h3>Your side-by-side view</h3><p>Indicative prices for {guests} guests · {event}</p></div><span className="compare-badge">{compare.length} vendors</span></div>
          {compare.length===0?<div className="empty-compare">Choose a caterer above to start comparing.</div>:<div className="comparison-table"><div className="comparison-row table-head"><span>WHAT MATTERS</span>{vendors.filter(v=>compare.includes(v.id)).map(v=><b key={v.id}>{v.name}</b>)}</div>
            {[["Est. per plate",v=>`₹${Math.round(v.base*(1-discount)).toLocaleString("en-IN")}`],["Est. event total",v=>`₹${(Math.round(v.base*(1-discount))*guests).toLocaleString("en-IN")}`],["Customer rating",v=>`★ ${v.rating} (${v.reviews})`],["Minimum guests",v=>`${v.min} people`],["Tasting session",v=>"Available on request"]].map(([label,fn])=><div className="comparison-row" key={label}><span>{label}</span>{vendors.filter(v=>compare.includes(v.id)).map(v=><strong key={v.id}>{fn(v)}</strong>)}</div>)}
          </div>}
          <p className="fine-print">*Vendor details and prices are illustrative demo data for this hackathon prototype. Confirm licences, food-safety practices, menu inclusions and final rates directly before booking.</p>
        </div>
      </div></section>

      <section className="how-section section" id="how"><div className="eyebrow">LESS BACK-AND-FORTH, MORE CELEBRATING</div><h2>From first idea to final plate.</h2><div className="how-grid"><div><span>01</span><h3>Tell us the plan</h3><p>Choose the occasion, guest count and dietary preference.</p></div><div><span>02</span><h3>Make it yours</h3><p>Build a menu from starters to dessert and see costs change.</p></div><div><span>03</span><h3>Compare with confidence</h3><p>Review caterers, request a tasting and take your quote to the team.</p></div></div></section>
    </main>

    <footer><a className="brand" href="#"><span className="brand-mark"><Utensils size={17}/></span><span>feastflow<span className="brand-dot">.</span><small>EVENTEATS EXCHANGE</small></span></a><p>Made for gatherings worth remembering.</p><span>Hackathon prototype · 2026</span></footer>

    {booking&&<div className="modal-backdrop" onClick={()=>setBooking(false)}><div className="booking-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setBooking(false)}><X size={18}/></button><div className="eyebrow">LET'S GET A TASTE</div><h2>Request a tasting.</h2><p>Share a few details and {bookVendor.name} can get in touch to arrange a session.</p><form onSubmit={submitBooking}><label>Your name<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Name"/></label><label>Preferred date<input required type="date" min={new Date().toISOString().slice(0,10)} value={date} onChange={e=>setDate(e.target.value)}/></label><label>Venue / area<input required value={venue} onChange={e=>setVenue(e.target.value)} placeholder="e.g. Gachibowli, Hyderabad"/></label><div className="modal-vendor"><ChefHat size={17}/><span>{bookVendor.name}<small>For {guests} guests · {event}</small></span></div><button className="primary-btn full-btn" type="submit">Send tasting request <span>→</span></button></form><small className="modal-note">Demo only: this request is stored in the page state and is not sent to a real vendor.</small></div></div>}
    {toast&&<div className="toast"><Check size={16}/>{toast}</div>}
  </div>;
}

createRoot(document.getElementById("root")).render(<App/>);